rootProject.name = "TerrariaModManager"
include(":app")
